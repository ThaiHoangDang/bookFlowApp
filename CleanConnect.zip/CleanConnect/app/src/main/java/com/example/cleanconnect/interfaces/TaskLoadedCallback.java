package com.example.cleanconnect.interfaces;

import java.util.List;

public interface TaskLoadedCallback {
    void onTaskDone(List<String> poly);
}
